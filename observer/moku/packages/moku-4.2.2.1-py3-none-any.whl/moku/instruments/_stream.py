import io
import json
from datetime import datetime
import socket
import time
from subprocess import DEVNULL, PIPE, Popen
from threading import Event, Thread
from typing import Protocol

from moku import MOKU_CLI_PATH
from moku.logging import get_logger
from moku.utilities import check_mokucli_version
from moku.exceptions import StreamException
from moku.session import RequestSession


logger = get_logger("stream")


class MokuCLIThread(Thread):
    """
    Threading class responsible for running the mokucli command.

    :param command: Command to execute as a subprocess
    :param error_event: Event object to set if an error occurs
    :param start_evt: Event object to set once the subprocess is launched
    """

    def __init__(
        self, command: list[str], error_event: Event, start_evt: Event | None = None
    ) -> None:
        self.command = command
        self.start_evt = start_evt
        self.error_event = error_event
        self.process: Popen | None = None
        super(MokuCLIThread, self).__init__(name="MokuCLIThread")

    def run(self):
        logger.info("Running: %s", " ".join(self.command))
        self.process = Popen(self.command, stdout=DEVNULL, stderr=PIPE)
        # signal subprocess launch...
        if self.start_evt:
            self.start_evt.set()
        self.process.wait()  # waits until the subprocess is finished executing
        error = self.process.stderr.read().decode("utf8")
        if self.process.returncode != 0 or error:
            self.error_event.set()
            raise StreamException(
                f"mokucli process exited with code {self.process.returncode}: {error}"
            )
        logger.info("mokucli exited with code %d", self.process.returncode)


class StreamInstrumentMembers(Protocol):
    """
    These are the data members that the StreamInstrument class expects to get
    from the class that inherits StreamInstrument.
    """

    session: RequestSession
    slot: int
    operation_group: str


class StreamInstrument(StreamInstrumentMembers):
    """
    Base class for all streaming features. Any instrument
    supporting data streaming should inherit this class.

    This class assumes that the class that inherits this class provides the
    data members listed in StreamInstrumentMembers.
    """

    def __init__(self) -> None:
        self.stream_id: str | None = None
        """
        The stream_id of the current streaming session. This must be set by
        the derived class once if has received the response from the Moku which
        includes the stream_id.
        """

        self.ip_address: str | None = None
        """
        The IP address of the Moku that is streaming data.
        This is needed to launch the mokucli subprocess to get stream data.
        This is reset back to None when either stop_streaming() is called or
        get_stream_data() detects the end of the stream.
        """

        self.port: int | None = None
        "The port number used to read the decoded stream data from the mokucli subprocess."

        self._socket_rdr: io.TextIOWrapper | None = None
        "The file to read decoded stream data from the mokucli subprocess."

        self._get_stream_data_thread: MokuCLIThread | None = None
        "This is the thread that run the mokucli process to support calls to get_stream_data()."

        self._error_event = Event()

    @staticmethod
    def _get_next_available_port():
        sock = socket.socket()
        sock.bind(("", 0))
        port = sock.getsockname()[1]
        sock.close()
        return port

    def _reset_stream_config(self):
        # Don't reset stream_id back to None as it is needed by get_chunk() to
        # get chunks after stop_streaming() has been called.
        self.ip_address = None
        self.port = None
        self._socket_rdr = None
        self._get_stream_data_thread = None
        self._error_event = Event()

    def _connect(self):
        """
        Tries to connect to the tcp port or raises Exception
        """
        i = 0
        while True:
            try:
                i += 1
                if self._error_event.is_set():
                    raise Exception
                client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                client.connect(("localhost", self.port))
                self._socket_rdr = client.makefile("r")
                break
            except socket.error:
                if i == 5:
                    raise Exception(f"Cannot connect to port {self.port}")
                time.sleep(0.5)

    def _start_get_stream_data_thread(self) -> None:
        check_mokucli_version(MOKU_CLI_PATH)
        assert MOKU_CLI_PATH is not None, "Is checked in check_mokucli_version()"
        self.port = self._get_next_available_port()
        _ip = f"--ip-address={self.ip_address}"
        _stream = f"--stream-id={self.stream_id}"
        _target = f"--target={self.port}"
        command = [MOKU_CLI_PATH, "stream", _ip, _stream, _target]
        _start_event = Event()

        self._get_stream_data_thread = MokuCLIThread(command, self._error_event, _start_event)
        self._get_stream_data_thread.start()
        _start_event.wait()
        self._connect()

    def start_streaming(self):
        """
        Base class start_streaming, verifies if streaming is possible
        """
        check_mokucli_version(MOKU_CLI_PATH)
        self.ip_address = self.session.ip_address

    def stop_streaming(self) -> None:
        """
        Stops the current instrument data streaming session.
        """
        operation = "stop_streaming"
        self.session.post(f"slot{self.slot}/{self.operation_group}", operation)

        if self._get_stream_data_thread and self._get_stream_data_thread.process:
            logger.info("Terminating mokucli process")
            self._get_stream_data_thread.process.terminate()
            self._get_stream_data_thread.join(timeout=2)
            assert not self._get_stream_data_thread.is_alive(), (
                "The mokucli process did not terminate"
            )

        self._reset_stream_config()

    def stream_to_file(self, name=None):
        """
        Streams the data to the file of desired format

        :type name: `string`
        :param name: Base name with one of csv, npy, mat extensions (defaults to csv) # noqa

        """
        if not self.ip_address:
            raise StreamException(
                "No streaming session in progress, start one using start_streaming"
            )
        if self._get_stream_data_thread:
            raise StreamException("Can't call stream_to_file() after calling get_stream_data()")

        check_mokucli_version(MOKU_CLI_PATH)
        _ip = f"--ip-address={self.ip_address}"
        _stream = f"--stream-id={self.stream_id}"

        if not name:
            _ts = datetime.now()
            name = f"STREAM_{_ts.strftime('%d%m%Y%H%M%S')}.csv"

        _target = f"--target={name}"
        command = [MOKU_CLI_PATH, "stream", _ip, _stream, _target]
        cli_thread = MokuCLIThread(command, self._error_event)
        cli_thread.start()

    def get_stream_data(self):
        """
        Get the converted stream of data

        :raises StreamException: Indicates END OF STREAM
        """
        if not self.ip_address:
            raise StreamException(
                "No streaming session in progress, start one using start_streaming"
            )  # noqa
        if self._error_event.is_set():
            raise Exception("An error occurred in the mokucli streaming process.")
        if not self._get_stream_data_thread:
            self._start_get_stream_data_thread()
        assert self._socket_rdr is not None  # is set by _connect()
        data = self._socket_rdr.readline()
        if data:
            if data == "EOS\n":
                self._reset_stream_config()
                raise StreamException("End of stream")
            return json.loads(data)
